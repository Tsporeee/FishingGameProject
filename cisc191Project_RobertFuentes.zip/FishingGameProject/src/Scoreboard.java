import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
/**
 * Lead Author(s): 
 * @author Robert Fuentes
 * 
 * Other contributors:
 * 
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 *  
 * Version/date: 10/31/2025
 * 
 * Responsibilities of class:
 * 
 * 
 */

public class Scoreboard
{
    // A Scoreboard has-many scores
    private ArrayList<String> scores = new ArrayList<String>();

    // Add a score
    public void addScore(String score)
    {
        scores.add(score);
    }

    // Get all scores
    public ArrayList<String> getScores()
    {
        return scores;
    }

    // Save scores to file
    public void saveScores()
    {
        try
        {
            FileWriter writer = new FileWriter("scoreboard.txt");
            for (String score : scores)
            {
                writer.write(score + "\n"); // write each score on its own line
            }
            writer.close();
        }
        catch (IOException e)
        {
            System.out.println("Something went wrong in saving score");
        }
    }

    // Load scores from file
    public void loadScores()
    {
        scores.clear(); // avoid duplicates if called multiple times
        try
        {
            BufferedReader reader = new BufferedReader(new FileReader("scoreboard.txt"));
            String line;
            while ((line = reader.readLine()) != null)
            {
                scores.add(line);
            }
            reader.close();
        }
        catch (IOException e)
        {
            System.out.println("Something went wrong in loading score");
        }
    }

    // (Optional helper used by your test) Print scores
    public void displayScores()
    {
        for (String s : scores)
        {
            System.out.println(s);
        }
    }
}
