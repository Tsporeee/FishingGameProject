/**
 * Lead Author(s): 
 * @author Robert Fuentes
 * 
 * Other contributors:
 * 
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 *  
 * Version/date: 10/31/2025
 * 
 * Responsibilities of class:
 * 
 * 
 */

public class TestRod
{
    public static void main(String[] args)
    {
        Rod rod = new Rod();

        System.out.println("Tool Name: " + rod.getName());
        rod.specialAbility();
    }
}
