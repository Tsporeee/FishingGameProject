/**
 * Lead Author(s): 
 * @author Robert Fuentes
 * 
 * Other contributors:
 * 
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 *  
 * Version/date: 10/31/2025
 * 
 * Responsibilities of class:
 * 
 * 
 */
public class TestScoreboard
{
    public static void main(String[] args)
    {
        System.out.println(" SCOREBOARD TESTING ");

        Scoreboard sb = new Scoreboard();

        // Add a single player score
        sb.addScore("Robert - 2 points");

        // Save and load scores
        sb.saveScores();
        sb.loadScores();

        // Display the score
        System.out.println("\nCurrent Scores:");
        sb.displayScores();
    }
}
